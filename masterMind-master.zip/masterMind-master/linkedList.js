var Peg = function (color) {


}

class LinkedList {

    constructor() {
        this.head = null;
        this.size = 0;
    }


}



module.exports.LinkedList = LinkedList;
